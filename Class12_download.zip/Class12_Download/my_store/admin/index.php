<?php


$html = <<< HEREDOC
<p>
後台管理系統
</p>
HEREDOC;

include 'pagemake.php';
pagemake($html, '');
?>