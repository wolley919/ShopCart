<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>資料管理系統</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<h1>資料管理系統─PDO版本</h1>
<p><a href="cust_list_page.php">db2 分頁列表</a></p>
<p><a href="cust_manage.php?op=LIST_PAGE">db3 分頁列表</a></p>
<HR>
<p><a href="cust_install_table.php">安裝資料表</a></p>

</body>
</html>