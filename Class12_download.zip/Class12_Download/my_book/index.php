<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>基本資料庫系統</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<p align="center"><a href="list_all.php">list_all 資料全部列出</a></p>
<p align="center"><a href="list_page.php">list_page 分頁列出</a></p>
<hr />
<p align="center"><a href="install.php">安裝資料庫或資料表</a></p>
</body>
</html>
